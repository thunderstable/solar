<template>
  <nav class="navbar navbar-expand-lg navbar-light  fixed-top" style="background-color:#212120 ; height:70px;">
    <div class="container-fluid">
      <a class="navbar-brand" href="#" style="font-weight:bold;color:#36B780;">
        <fa icon="home" style="width:30px;height:22px;" /> <a style="font-size:18px">SOLAR PUMP STATION | <a
            style="font-size:14px;color:white;"> โครงการสูบน้ำบาดาล</a></a></a>

      <!-- <div class="text-white">Data Station From API</div> -->


    </div>
  </nav>

  <main style="background-color:#F7F7F7;">
    <div style="height:100px;"></div>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-12">
          <div class="row">
            <div class="text-center fs-5">
              โครงการสูบน้ำบาดาลด้วยพลังงานแสงอาทิตย์
            </div>
            <div class="text-center">
              (รวมสถานนีสูบน้ำ)
            </div>
            <!-- <a class="btn btn-primary" data-bs-toggle="modal" href="#exampleModalToggle" role="button">Open first modal</a> -->
            <div class="fixed-bottom col-12 pe-5 mb-5 d-flex justify-content-end">
              <div class="col-1 me-2 mb-2">
                <div class="text-center ">
                  <button type="button" class="btn btn-default btn-circle btn-xl " data-bs-toggle="modal"
                    href="#exampleModalToggle" style="background-color:#F5F5F5;">
                    <fa icon="cog" style="width:30px;height:22px;" />
                  </button>
                </div>
                <div class="text-center">Login</div>
              </div>

            </div>


            <div class="col-10 col-xl-3 col-lg-3 col-md-5 col-sm-10" v-for="item in items" :key="item.message">
              <br>
              <div class="card text-center" style="width: 18rem;">



                <div
                  style="height:120px;background-image: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRgOwWKKT01xD3DkpahJK51RORF-tFEwYpjqA&usqp=CAU');background-repeat: no-repeat; background-size: cover;">
                  <h5 class="card-title mt-2"> สถานีสูบน้ำบาดาล {{item.message}}</h5>
                  <div class="" style="background-color:rgb(249 250 251 / 87%);">
                    <div style="height:5px"></div>
                    <div>แรงดัน &nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;กระแส&nbsp;&nbsp; | &nbsp;&nbsp; กำลัง &nbsp;&nbsp;
                    </div>
                    <div class="btn-group" role="group" aria-label="Basic example">
                      <button type="button" class="btn " style="background-color:#A6B9A9;">120 V</button>
                      <button type="button" class="btn " style="background-color:#5D9C67;">3.12 A</button>
                      <button type="button" class="btn " style="background-color:#A6B9A9">3.2 kW</button>
                    </div>
                    <div style="height:10px"></div>
                  </div>
                </div>
                <!-- <div>แรงดัน &nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;กระแส&nbsp;&nbsp; | &nbsp;&nbsp; กำลัง &nbsp;&nbsp; </div>
                  <div class="btn-group" role="group" aria-label="Basic example" > 
                  <button type="button" class="btn " style="background-color:#A6B9A9;">120 V</button>
                  <button type="button" class="btn " style="background-color:#5D9C67;">3.12 A</button>
                  <button type="button" class="btn " style="background-color:#A6B9A9">3.2 kW</button>                
                  </div>   -->
                <div class="card-body">


                  <div style="font-size:12px;">Pump Status<li class="text-success">ON</li>
                  </div>
                  <p class="card-text">รายละเอียดย่อต่างๆในสถานี {{item.message}}</p>
                  <!-- <a href="#" class="btn text-white" style="background-color:#414952;font-size:14px;">Go to Dashboard</a> -->
                  <!-- <router-link to="/dashboard" tag="button">Dashboard</router-link> -->
                  <button @click="$router.push('dashboard')" type="button" class="btn btn-secondary">Go to
                    Dashboard</button>
                  <!-- <router-link to="/dashboard" tag="button">foo</router-link> -->
                </div>
              </div>

            </div>


          </div>

        </div>
      </div>
      <!-- Modal -->
      <div class="modal fade " id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel"
        tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalToggleLabel">Setting | การตั้งค่า</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" style="height:500px;">

             <div class="row justify-content-center">
                <div class="col-xl-4 col-10">
                <form>
                  <h2 class="text-center mb-3 mt-3">[ LOGO ]</h2>

                  <div class="mb-1">
                    <label for="exampleInputEmail1" class="form-label">Username</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                    <div id="emailHelp" class="form-text"></div>
                  </div>
                  <div class="mb-2">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1">
                  </div>
                 
                  <div class="text-center">
                    <button type="submit" class=" btn btn-success">Login</button>
                  </div>
                </form>
              </div>
             </div>

            </div>
            <div class="modal-footer">
              <button class="btn btn-success" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal"
                data-bs-dismiss="modal">ปิด</button>
            </div>
          </div>
        </div>
      </div>

    </div>


  </main>


</template>

<script>
  console
  import VueApexCharts from "vue3-apexcharts";
  import Slider from '@vueform/slider';
  export default {
    components: {
      apexchart: VueApexCharts,
      Slider,
    },
    data: function () {
      return {
        items: [{
            message: '1'
          },
          {
            message: '2'
          },
          {
            message: '3'
          },
          {
            message: '4'
          },
          {
            message: '5'
          }
        ],
        G1: 10,
        value: 20,

        optionM: 'ความสูงบานประตู',

        doorflow1: 0,
        doorflow2: 0,
        doorflow3: 0,
        doorflow4: 0,

        doorflowS1: 0,
        doorflowS2: 0,
        doorflowS3: 0,
        doorflowS4: 0,

        series: [{
          name: 'หน้าบาน',
          data: [9, 10, 10, 7, 7, 8, 11],
          //  color:'#1134A6'
          color: '#FD6A6A'
        }, {
          name: 'หลังบาน',
          data: [10, 9, 8, 7, 8, 6, 10],
          color: '#FEB019'

          //  color:'#0080FE'

          //  color:'#1134A6'
        }],
        chartOptions: {
          chart: {
            height: 350,
            type: 'area',
            //  colors:['#FF4560', '#FF4560']
            // style:{
            //     colors:['	#FF4560', '#FF4560']
            //       },

          },

          dataLabels: {
            // style:{
            //       colors:['#FF4560', '#FF4560']
            //         },
            enabled: false,
          },



          // fill:{
          //   colors: ['#b14343', '#b14343']
          // },

          stroke: {
            curve: 'smooth'
          },
          xaxis: {
            type: 'datetime',
            categories: ["2018-09-19T00:00:00.000Z", "2018-09-19T01:30:00.000Z", "2018-09-19T02:30:00.000Z",
              "2018-09-19T03:30:00.000Z", "2018-09-19T04:30:00.000Z", "2018-09-19T05:30:00.000Z",
              "2018-09-19T06:30:00.000Z"
            ]
          },
          tooltip: {
            x: {
              format: 'dd/MM/yy HH:mm'
            },
          },
        },
        series2: [90, 70, 79, 92],
        chartOptions2: {



          chart: {
            height: 300,
            type: 'radialBar',

          },

          plotOptions: {

            radialBar: {

              offsetY: 0,
              startAngle: 0,
              endAngle: 270,

              hollow: {
                margin: 5,
                size: '30%',
                background: 'transparent',
                image: undefined,

              },
              dataLabels: {
                name: {
                  show: false,
                },
                value: {


                }
              },

            }

          },

          colors: ['#1ab7ea', '#0084ff', '#39539E', '#0077B5'],
          labels: ['บานที่ 1 ', 'บานที่ 2 ', 'บานที่ 3 ', 'บานที่ 4 '],
          legend: {
            show: true,
            floating: true,
            fontSize: '14px',
            position: 'left',
            offsetX: 50,
            offsetY: -10,
            labels: {
              useSeriesColors: true,
            },
            markers: {
              size: 0
            },
            formatter: function (seriesName, opts) {
              return seriesName + ":  " + opts.w.globals.series[opts.seriesIndex]
            },
            itemMargin: {
              vertical: 3
            }
          },
          responsive: [{
            breakpoint: 480,
            options: {
              legend: {
                show: false
              }
            }
          }]
        },


        series3: [0],
        series33: this.series3,
        chartOptions3: {
          chart: {
            height: 250,
            type: 'radialBar',
            offsetY: -20
          },
          plotOptions: {
            radialBar: {
              startAngle: -135,
              endAngle: 135,
              dataLabels: {
                name: {
                  fontSize: '16px',
                  color: '#424949',
                  offsetY: 82
                },
                value: {
                  offsetY: -5,
                  fontSize: '20px',
                  color: '#C0392B',
                  formatter: function (val) {
                    return val + "%";
                  }
                }
              }
            }
          },
          fill: {
            type: 'gradient',
            colors: '#C0392B',
            gradient: {

              shade: 'dark',
              shadeIntensity: 0.15,
              inverseColors: false,
              opacityFrom: 1,
              opacityTo: 1,
              stops: [0, 50, 65, 91]

            },

          },
          stroke: {
            dashArray: 4
          },
          labels: ['ความสูงบานประตู(%)'],
        },



        series4: [{
          name: 'หน้าบาน',
          data: [4.5]
        }, {
          name: 'หลังบาน',
          data: [3.5]
        }, ],
        chartOptions4: {
          chart: {
            type: 'bar',
            height: 350
          },
          plotOptions: {
            bar: {
              horizontal: false,
              columnWidth: '70%',
              endingShape: 'rounded'
            },
          },
          dataLabels: {
            enabled: false
          },
          stroke: {
            show: true,
            width: 2,
            colors: ['transparent']
          },
          xaxis: {
            categories: ['หน้าบาน', 'หลังบาน'],
          },
          yaxis: {
            title: {
              text: 'ความสูง (m)'
            }
          },
          fill: {
            opacity: 1,
            colors: ['#1da32e', '#d39a33'],
          },
          tooltip: {
            y: {
              formatter: function (val) {
                return "$ " + val + " thousands"
              }
            }
          }
        },

        series5: [{
          name: 'Net Profit',
          data: [4.5, 3.5, 4.5, 3.0]
        }, ],
        chartOptions5: {
          chart: {
            type: 'bar',
            height: 350
          },
          plotOptions: {
            bar: {
              horizontal: false,
              columnWidth: '55%',
              endingShape: 'rounded'
            },
          },
          dataLabels: {
            enabled: false
          },
          stroke: {
            show: true,
            width: 2,
            colors: ['transparent']
          },
          xaxis: {
            categories: ['บานที่หนึ่ง', 'บานที่สอง', 'บานที่สาม', 'บานที่สี่'],
          },
          yaxis: {
            title: {
              text: 'ความสูง (m)'
            }
          },
          fill: {
            opacity: 1
          },
          tooltip: {
            y: {
              formatter: function (val) {
                return "$ " + val + " thousands"
              }
            }
          }
        },



      };
    },

    methods: {
      updateChart() {
        const max = 90;
        const min = 20;
        const newData = this.series[0].data.map(() => {
          return Math.floor(Math.random() * (max - min + 1)) + min;
        });

        const colors = ["#008FFB", "#00E396", "#FEB019", "#FF4560", "#775DD0"];

        // Make sure to update the whole options config and not just a single property to allow the Vue watch catch the change.
        this.chartOptions = {
          colors: [colors[Math.floor(Math.random() * colors.length)]],
        };

        // In the same way, update the series option
        this.series = [{
          data: newData,
        }, ];
        /** If i try to change the type i will get an error */
        this.type = "line";
      },

      Bflow1: function (val) {
        this.doorflowS1 = val
        vm.$forceUpdate();
      },
      Bflow2: function (val) {
        this.doorflowS2 = val
      },
      Bflow3: function (val) {
        this.doorflowS3 = val
      },
      Bflow4: function (val) {
        this.doorflowS4 = val
      },
    },




  };
</script>




<style src="@vueform/slider/themes/default.css">

</style>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Prompt:wght@300&display=swap');
  @import url('https://fonts.googleapis.com/css2?family=Itim&display=swap');

  div,
  a {
    font-family: 'Prompt', sans-serif;
    /* font-family: 'Itim', cursive; */
    /* color: rgb(92, 91, 91); */
  }

  .btn-circle.btn-xl {
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
    width: 70px;
    height: 70px;
    padding: 10px 16px;
    border-radius: 35px;
    font-size: 24px;
    line-height: 1.33;
  }

  .slider-red {
    --slider-connect-bg: #c94b1c;
    --slider-tooltip-bg: #c94b1c;
    --slider-handle-ring-color: #EF444430;

  }

  .sidebar {
    position: fixed
  }

  .dot {
    height: 35px;
    width: 35px;
    background-color: #1da32e;
    border-radius: 50%;
    display: inline-block;
  }
</style>