<template>

  <body style="background-color:; height:100vh" onload="startTime()">
    <!-- <nav class="navbar navbar-expand-lg navbar-light " style="background-color:#9E9D9D;">
      <a class="mx-3">
        <a class="navbar-brand" href="#"> DASHBOARD | </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
          aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Graph</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Export</a>
            </li>
          </ul>
        </div>
      </a>
    </nav> -->

    <nav class="navbar navbar-light fixed-top" style="background-color:grey;">
      <div class="container-fluid">
        <div class="d-md-block ">

          <ul class="nav nav-pills   " id="pills-tab" role="tablist">
            <li class="nav-item" role="presentation">
              <button class="nav-link active " id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home"
                type="button" role="tab" aria-controls="pills-home" aria-selected="true">
                <span>Home</span>
              </button>
            </li>
            <li class="nav-item" role="presentation">
              <button class="nav-link" id="pills-chart-tab" data-bs-toggle="pill" data-bs-target="#pills-chart"
                type="button" role="tab" aria-controls="pills-chart" aria-selected="false">
                <span>Graph</span> </button>
            </li>
            <li class="nav-item" role="presentation">
              <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact"
                type="button" role="tab" aria-controls="pills-contact" aria-selected="false">
                <span>Export</span></button>
            </li>

          </ul>
        </div>

      </div>

    </nav>

    <main style="background-color:#E6E6E8 ; min-height: 100vh;">
      <div class="tab-content" id="pills-tabContent">
        <div class="tab-pane fade show active " id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
          <div style="height:55px;"></div>
          <!-- <div class="fs-5 " style="height:35px;background-color:#E2E2E2;">

           <div class="pt-1"> &nbsp;&nbsp;&nbsp;&nbsp;HOME | หน้าแสดงผลหลัก</div>
          </div> -->
          <div class="container">

            <div class="fs-5 " style="height:35px;">

              <div class="pt-2"><a style="color:grey;">HOME</a> | Power Consumption</div>
            </div>

            <div class="row mt-2">
              <div class="col">
                <div class="row justify-content-center">

                </div>


                <div class="row justify-content-center border rounded-3 bg-white ">


                  <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12 col-12">
                    <div class="">
                      <div class="mt-3">
                        <div class="text-center">กราฟแสดงผล Realtime</div>
                        <div id="chart">
                          <apexchart type="area" height="290" :options="chartOptions" :series="series"></apexchart>
                        </div>
                      </div>
                    </div>
                  </div>


                  <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4 col-4">
                    <h5 class="text-center mt-5" style="color:grey;">VOLTAGE</h5>
                    <div id="card">
                      <div id="chart">
                        <apexchart type="radialBar" height="180" :options="chartOptionsb" :series="seriesb">
                        </apexchart>
                      </div>
                    </div>
                    <h5 class="card-title text-center fs-2">122 V</h5>
                    <div class="text-center"><u style="color:grey;">Volt</u></div>
                  </div>

                  <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4 col-4">
                    <h5 class="text-center mt-5" style="color:grey;">CURRENT</h5>
                    <div id="card">
                      <div id="chart">
                        <apexchart type="radialBar" height="180" :options="chartOptionsb" :series="seriesb">
                        </apexchart>
                      </div>
                    </div>
                    <h5 class="card-title text-center fs-2">2.4 A</h5>
                    <div class="text-center"><u style="color:grey;">Amp</u></div>
                  </div>

                  <div class="col-xl-2 col-lg-2 col-md-4 col-sm-4 col-4">
                    <h5 class="text-center mt-5" style="color:grey;">POWER</h5>
                    <div id="card">
                      <div id="chart">
                        <apexchart type="radialBar" height="180" :options="chartOptionsb" :series="seriesb">
                        </apexchart>
                      </div>
                    </div>
                    <h5 class="card-title text-center fs-2">500 W</h5>
                    <div class="text-center"><u style="color:grey;">Watt</u></div>
                  </div>
                  <div style="height:20px;"></div>
                  <!-- <div class="col-2">
                    <div class="card text-dark bg-white mb-3 me-2" style="max-width: 18rem;">
                    <div class="card-header">Voltage</div>
                    <div class="card-body">
                      <div id="card">
                        <div id="chart">
                          <apexchart type="radialBar" height="200" :options="chartOptionsb" :series="seriesb">
                          </apexchart>
                        </div>
                      </div>
                      <h5 class="card-title text-center fs-2">122 V</h5>
                      <div class="text-center"><u>Volt</u></div>
                    </div>
                  </div>
              </div> -->

                  <!-- <div class="col-2">
                    <div class="card text-dark bg-white mb-3 me-2" style="max-width: 18rem;">
                      <div class="card-header">Current</div>
                      <div class="card-body">
                        <div id="chart">
                          <apexchart type="radialBar" height="200" :options="chartOptionsb" :series="seriesb">
                          </apexchart>
                        </div>
                        <h5 class="card-title text-center fs-2">2.1 A</h5>
                        <div class="text-center"><u>Amp</u></div>
                      </div>
                    </div>
                  </div> -->

                  <!-- <div class="col-2">
                    <div class="card text-dark bg-white mb-3 me-2" style="max-width: 18rem;">
                      <div class="card-header">Power</div>
                      <div class="card-body">
                        <div id="chart">
                          <apexchart type="radialBar" height="200" :options="chartOptionsb" :series="seriesb">
                          </apexchart>
                        </div>
                        <h5 class="card-title text-center fs-2">256.2 V</h5>
                        <div class="text-center"><u>Watt</u></div>
                      </div>
                    </div>
                  </div> -->


                </div>

                <div class="fs-5 mt-1 " style="height:35px;background-color:">
                  <div class="pt-2"><a style="color:grey;">HOME</a> | More Detail</div>
                </div>
                <div class="row border rounded-3 bg-white mt-2">
                  <div class="row mt-3 mb-3 justify-content-center">

                    <div class="mt-3 col-xl-2 col-lg-2 col-md-2 col-md-5 col-10">
                      <div class="card text-center">
                        <div class="card-header">
                          STATION
                        </div>
                        <div class="card-body">
                          <h6 class="card-title" style="font-size:14px;color:grey;">สถานะการทำงานสถานีสูบ</h6>
                          <div class="text-success">Online</div>

                          <img src="https://pngimg.com/uploads/solar_panel/solar_panel_PNG118.png"
                            style="height:120px;" />
                        </div>

                      </div>
                    </div>


                    <div class="mt-3 col-xl-2 col-lg-2 col-md-2 col-md-5 col-10">
                      <div class="card text-center">
                        <div class="card-header">
                          PUMP STATUS
                        </div>
                        <div class="card-body">
                          <h6 class="card-title" style="font-size:14px;color:grey;">สถานะปั๊ม</h6>
                          <div class="text-success">ON</div>

                          <img
                            src="https://media.istockphoto.com/vectors/industrial-electric-motor-vector-id944406686?k=20&m=944406686&s=612x612&w=0&h=sALcy25szImDT1m6wprrFs6Txq3lEfWxue3r1ZRa6rw="
                            style="height:120px;" />
                        </div>

                      </div>
                    </div>

                    <div class="mt-3 col-xl-2 col-lg-2 col-md-2 col-md-5 col-10">
                      <div class="card text-center">
                        <div class="card-header">
                          RUN HOUR
                        </div>
                        <div class="card-body">
                          <h6 class="card-title" style="font-size:14px;color:grey;">ชั่วโมงการทำงาน</h6>
                          <div class="text-success">100:11 HH:mm</div>

                          <img
                            src="https://media.istockphoto.com/vectors/industrial-electric-motor-vector-id944406686?k=20&m=944406686&s=612x612&w=0&h=sALcy25szImDT1m6wprrFs6Txq3lEfWxue3r1ZRa6rw="
                            style="height:120px;" />
                        </div>

                      </div>
                    </div>


                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
        <div class="tab-pane fade" id="pills-chart" role="tabpanel" aria-labelledby="pills-chart-tab">

          <!-- <div style="height:200px"></div> -->
          <div class="container">
            <div class="row mt-2 justify-content-center text-center">
              <div class="col mt-5 ">

                <div class="col-12 mt-2  bg-white rounded-3">
                  <div class="pt-3  h5">
                    กราฟแสดงการใช้พลังงาน
                  </div>
                  <div id="chart">
                    <div class="toolbar">
                      <br>
                      <div class="row">
                        <div class="col-2"></div>
                        <div class="col-8 ">
                          <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                            <input type="radio" class="btn-check" name="btnradio" id="btnradio1" autocomplete="off"
                              checked>
                            <label class="btn btn-outline-secondary" for="btnradio1">&nbsp;1 Day&nbsp;</label>

                            <input type="radio" class="btn-check" name="btnradio" id="btnradio2" autocomplete="off">
                            <label class="btn btn-outline-secondary" for="btnradio2">1 Week</label>

                            <input type="radio" class="btn-check" name="btnradio" id="btnradio3" autocomplete="off">
                            <label class="btn btn-outline-secondary" for="btnradio3">1 Month</label>

                            <input type="radio" class="btn-check" name="btnradio" id="btnradio4" autocomplete="off">
                            <label class="btn btn-outline-secondary" for="btnradio3">3 Month</label>
                          </div>
                        </div>
                        <!-- <div class="col-2">
                          <div class="text-start" style="font-size: 9px;">
                            Realtime
                          </div>
                          <span class="form-check form-switch">
                            <input class="form-check-input" style="width: 43px; height: 22px;" type="checkbox"
                              @click="clickrealtime()" checked>
                          </span>
                          <br>
                          <br>
                        </div> -->
                      </div>

                    </div>

                    <div id="chartAllSensor" width="900px" max-height="380px">
                      <apexchart type="line" height="250" ref="chartAllSensor" :options="chartOptionsAllSensor"
                        :series="seriesAllSensor">
                      </apexchart>
                    </div>

                    <div class="mb-2">Voltage, Amp and Power</div>

                  </div>
                  <div id="chartSparkAll" width="900px" max-height="380px">
                    <apexchart type="line" height="250" ref="chartSparkAll" :options="chartOptionsAlldevice"
                      :series="Sallrealtime">
                    </apexchart>
                  </div>

                  <div class="">Realtime All Device (Amp)</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
          <div style="height:200px"></div>
          <h1>Export</h1>
        </div>
      </div>
    </main>

  </body>

</template>

<script>
  import VueApexCharts from "vue3-apexcharts";
  var currentdata = [
    [1486771200000, 43],
    [1486857600000, 31],
    [1486944000000, 43],
    [1487030400000, 33],
    [1487116800000, 52]
  ];
  var voltagedata = [
    [1486857600000, 31],
    [1486944000000, 42],
    [1487030400000, 34],
    [1487116800000, 42]
  ];
  var powerdata = [];


  var AP1_I = [
    [1486771200000, 43],
    [1486857600000, 31],
    [1486944000000, 43],
    [1487030400000, 33],
    [1487116800000, 52]
  ];
  var SP1_I = [];
  var BP1_I = [];
  var MT1_I = [];
  var BT2_I = [];
  export default {
    components: {
      apexchart: VueApexCharts,
    },
    data: function () {
      return {
        seriesb: [72],
        chartOptionsb: {
          chart: {
            height: 350,
            type: 'radialBar',
            toolbar: {
              show: true
            }
          },
          plotOptions: {
            radialBar: {
              startAngle: -135,
              endAngle: 225,
              hollow: {
                margin: 0,
                size: '52%',
                background: '#fff',
                image: undefined,
                imageOffsetX: 0,
                imageOffsetY: 0,
                position: 'front',
                dropShadow: {
                  enabled: true,
                  top: 3,
                  left: 0,
                  blur: 4,
                  opacity: 0.24
                }
              },
              track: {
                background: '#fff',
                strokeWidth: '36%',
                margin: 0, // margin is in pixels
                dropShadow: {
                  enabled: true,
                  top: -3,
                  left: 0,
                  blur: 4,
                  opacity: 0.35
                }
              },

              dataLabels: {
                show: true,
                name: {
                  offsetY: -15,
                  show: true,
                  color: '#888',
                  fontSize: '13px'
                },
                value: {
                  formatter: function (val) {
                    return parseInt(val);
                  },
                  offsetY: 0,
                  color: '#111',
                  fontSize: '30px',
                  show: true,
                }
              }
            }
          },
          fill: {
            type: 'gradient',
            gradient: {
              shade: 'dark',
              type: 'horizontal',
              shadeIntensity: 0.5,
              gradientToColors: ['#ABE5A1'],
              inverseColors: true,
              opacityFrom: 1,
              opacityTo: 1,
              stops: [0, 100]
            }
          },
          stroke: {
            lineCap: 'round'
          },
          labels: ['Percent'],
        },
        Sallrealtime: [{
            name: "Amp",
            data: AP1_I.slice()
          }, {
            name: "Voltage",
            data: SP1_I.slice()
          },

        ],

        chartOptionsAlldevice: {
          chart: {
            height: 380,
            width: "100%",
            type: 'line',

            toolbar: {
              show: true,
              offsetX: 0,
              offsetY: 0,
              tools: {
                download: true,
                selection: true,
                zoom: true,
                zoomin: true,
                zoomout: true,
                pan: true,
                customIcons: []
              },
              autoSelected: 'zoom'
            },

          },

          colors: ['#4F953A', '#545454', '#D3C443', '2DBD40', '#BD2D49'],
          dataLabels: {
            enabled: false,
          },

          stroke: {
            show: true,
            curve: 'smooth',
            lineCap: 'butt',
            colors: undefined,
            width: 2,
            dashArray: 0,
          },
          xaxis: {
            range: 100000,
            type: 'datetime',
            /* range: XAXISRANGE, */
            labels: {
              datetimeUTC: false,
              datetimeFormatter: {
                year: 'yyyy',
                month: "MMM 'yy",
                day: 'dd MMM',
                hour: 'HH:mm:ss',
              }
            },
          },
          yaxis: [

          ],
          tooltip: {
            x: {
              show: true,
              format: 'dd MMM yy HH:mm:ss',
              formatter: undefined,
            }
          },
        },


        seriesAllSensor: [{
            name: "Voltage",
            data: voltagedata.slice()
          }, {
            name: "Amp",
            data: currentdata.slice()
          },
          {
            name: "kWatt",
            data: powerdata.slice()
          },
        ],

        chartOptionsAllSensor: {
          chart: {
            height: 380,
            width: "100%",
            type: 'line',

            toolbar: {
              show: true,
              offsetX: 0,
              offsetY: 0,
              tools: {
                download: true,
                selection: true,
                zoom: true,
                zoomin: true,
                zoomout: true,
                pan: true,
                customIcons: []
              },
              export: {
                csv: {
                  filename: 'AllSensor',
                  columnDelimiter: ',',
                  headerCategory: 'Time',
                  headerValue: 'value',
                  dateFormatter(timestamp) {
                    return new Date(timestamp)
                  }
                },
                svg: {
                  filename: 'AllSensor',
                },
                png: {
                  filename: 'AllSensor',
                }
              },
              autoSelected: 'zoom'
            },


          },

          colors: ['#4F953A', '#545454', '#70569E', ],
          dataLabels: {
            // enabled: true,
          },

          stroke: {
            show: true,
            curve: 'smooth',
            lineCap: 'butt',
            colors: undefined,
            width: 2,
            dashArray: 0,
          },
          xaxis: {
            type: 'datetime',
            /* range: XAXISRANGE, */
            labels: {
              datetimeUTC: false,
              datetimeFormatter: {
                year: 'yyyy',
                month: "MMM 'yy",
                day: 'dd MMM',
                hour: 'HH:mm:ss',
              }
            },
          },
          yaxis: [

          ],
          tooltip: {
            x: {
              show: true,
              format: 'dd MMM yy HH:mm:ss',
              formatter: undefined,
            }
          },
        },


        series: [{
            name: 'Voltage',
            data: [120, 120, 120, 121, 122, 123, 124]
          }, {
            name: 'Amp',
            data: [6.1, 6.2, 7.5, 7.2, 8.4, 5.2, 6.1]
          }, {
            name: 'Watt',
            data: [2.2, 3.1, 3.2, 3.4, 3.4, 3.5, 3.6, 3.1]
          }

        ],
        chartOptions: {
          chart: {
            height: 350,
            type: 'area'
          },
          dataLabels: {
            enabled: false
          },
          stroke: {
            curve: 'smooth'
          },
          xaxis: {
            type: 'datetime',
            categories: ["2018-09-19T00:00:00.000Z", "2018-09-19T01:30:00.000Z", "2018-09-19T02:30:00.000Z",
              "2018-09-19T03:30:00.000Z", "2018-09-19T04:30:00.000Z", "2018-09-19T05:30:00.000Z",
              "2018-09-19T06:30:00.000Z"
            ]
          },
          stroke: {
            show: true,
            curve: 'smooth',
            lineCap: 'butt',
            colors: undefined,
            width: 2,
            dashArray: 0,
          },
          tooltip: {
            x: {
              format: 'dd/MM/yy HH:mm'
            },
          },
        },
      };
    },

    methods: {

    },
  };

  function startTime() {
    const today = new Date();
    let h = today.getHours();
    let m = today.getMinutes();
    let s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('txt').innerHTML = h + ":" + m + ":" + s;
    setTimeout(startTime, 1000);
  }

  function checkTime(i) {
    if (i < 10) {
      i = "0" + i
    }; // add zero in front of numbers < 10
    return i;
  }
</script>

<style>
  @import url('https://fonts.googleapis.com/css2?family=Prompt:wght@300&display=swap');
  @import url('https://fonts.googleapis.com/css2?family=Itim&display=swap');

  div {
    font-family: 'Prompt', sans-serif;
    /* font-family: 'Itim', cursive; */
    /* color: rgb(92, 91, 91); */
  }

  .nav-pills .nav-link.active {
    /* background-color: hsl(130, 85%, 61%) !important; */
    background-color: #ed521896 !important;
    color: #ffffff !important;
  }

  .dot {
    height: 25px;
    width: 25px;
    background-color: rgb(22, 117, 65);
    border-radius: 50%;
    display: inline-block;
  }

  .sidebar {
    position: fixed
  }

  .nav-pills .nav-link.active {
    /* background-color: hsl(130, 85%, 61%) !important; */
    background-color: #a9b1bba6 !important;
    color: #066f1e !important;
  }

  .nav-pills .nav-link {
    color: #0d0e0d !important;
  }

  .rounded-pill-1 {
    border-radius: 1rem !important;
  }
</style>