import { createRouter, createWebHistory } from 'vue-router'
import Home from '../components/indashboard';
import About from '../components/dashboard';

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/dashboard',
    name: 'About',
    component: About
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
